No *Dockerfile* here. You should use the stock image available at Docker Hub. 
