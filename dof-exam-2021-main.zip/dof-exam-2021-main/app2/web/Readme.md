You should build an image using this *Dockerfile* and publish it to a Docker registry, for example Docker Hub.
